# CS 688 - Assignment 0

---

## Compilation
------------
The program compilation process is unchanged from the instructions. Assuming that the A0/ folder is in the same directory as the shared/ folder, which are both in the /cs488 directory which contains all the bundled libraries.

```
cd A0
premake4 gmake
make
```

## Manual
------------
The program should run using the command ./A0 and then it performs all the required functions in the assignment specification. No further assumptions were made.
